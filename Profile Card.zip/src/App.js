import React from "react";
import ProfileCard from "./components/ProfileCard";

const App = () => {
    return (
        <div className="">
            <ProfileCard />
        </div>
    );
};

export default App;
